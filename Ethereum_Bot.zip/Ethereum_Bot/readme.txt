✅ 1) Download the archive.
✅ 2) Unzip in new folder.
✅ 3) Open setup.exe file
✅ 4) Disable Windows Smart Screen, as well as update the Visual C++  package